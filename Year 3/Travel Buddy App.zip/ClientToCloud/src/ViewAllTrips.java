
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ViewAllTrips extends JFrame {

    private JTable tripsTable;
    private JTextField tripIDField;
    private JTextField locationField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JTextArea weatherDetailsTextArea;
    private boolean isSelectionChanging = false;

    public ViewAllTrips(int userID) {
        initComponents(userID);
        startTripsUpdateTimer(userID);
    }

    private void initComponents(int userID) {
        setTitle("All Trips");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        // Create JTable with fixed columns and rows
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Cells are not editable by the user
            }
        };

        model.addColumn("Trip ID");
        model.addColumn("User ID");
        model.addColumn("Location");
        model.addColumn("Start Date");
        model.addColumn("End Date");

        tripsTable = new JTable(model);
        tripsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tripsTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(tripsTable);
        add(scrollPane, BorderLayout.EAST);

        // Create JTextFields to display selected row values
        tripIDField = new JTextField();
        locationField = new JTextField();
        startDateField = new JTextField();
        endDateField = new JTextField();

        // Set text fields as non-editable
        tripIDField.setEditable(false);
        locationField.setEditable(false);
        startDateField.setEditable(false);
        endDateField.setEditable(false);

        JPanel detailsPanel = new JPanel(new GridLayout(5, 2));
        detailsPanel.add(new JLabel(" Trip ID:"));
        detailsPanel.add(tripIDField);
        detailsPanel.add(new JLabel(" Location:"));
        detailsPanel.add(locationField);
        detailsPanel.add(new JLabel(" Start Date:"));
        detailsPanel.add(startDateField);
        detailsPanel.add(new JLabel(" End Date:"));
        detailsPanel.add(endDateField);

        // Add a weather details panel below End Date
        detailsPanel.add(new JLabel(" Weather Details:"));
        weatherDetailsTextArea = new JTextArea();
        weatherDetailsTextArea.setEditable(false);  // Set as non-editable
        detailsPanel.add(new JScrollPane(weatherDetailsTextArea));

        // Set the details panel as non-editable
        for (Component component : detailsPanel.getComponents()) {
            if (!(component instanceof JTextField)) {
            } else {
                ((JTextField) component).setEditable(false);
            }
        }

        // Add listener to the location field to update weather details
        locationField.getDocument().addDocumentListener(new SimpleDocumentListener(() -> {
            updateWeatherDetails(locationField.getText());
        }));

        detailsPanel.setPreferredSize(new Dimension(300, detailsPanel.getHeight()));
        add(detailsPanel, BorderLayout.WEST);

        // Button to express interest
        JButton expressInterestButton = new JButton("Express Interest");
        expressInterestButton.addActionListener((ActionEvent e) -> {
            int selectedRow = tripsTable.getSelectedRow();
            if (selectedRow != -1) {
                String selectedTripID = (String) tripsTable.getValueAt(selectedRow, 0);

                // Create JSON payload
                JsonObject jsonInput = new JsonObject();
                jsonInput.addProperty("UserID", userID);
                jsonInput.addProperty("TripID", selectedTripID);
                String jsonPayload = jsonInput.toString();

                // Send HTTP POST request
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                            .uri(URI.create("http://20.115.50.61:8080/Service/express-interest"))
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                            .build();

                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                    // Handle response and show pop-up message
                    handleExpressInterestResponse(response);
                    System.out.println(jsonPayload);

                } catch (IOException | InterruptedException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Failed to send request. Check server availability.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(this, "Please select a trip to express interest.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener((ActionEvent e) -> {
            this.setVisible(true);
            new Home(userID).setVisible(true);
            dispose(); // Close the current frame
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(expressInterestButton);
        buttonPanel.add(backButton);

        add(buttonPanel, BorderLayout.SOUTH);

        fetchAndDisplayTrips(userID);

        // Display selected row details when a row is selected
        tripsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                // Selection change is finished
                isSelectionChanging = true;  // Set the flag
                int selectedRow = tripsTable.getSelectedRow();
                if (selectedRow != -1) {
                    tripIDField.setText((String) tripsTable.getValueAt(selectedRow, 0));
                    locationField.setText((String) tripsTable.getValueAt(selectedRow, 2));
                    startDateField.setText((String) tripsTable.getValueAt(selectedRow, 3));
                    endDateField.setText((String) tripsTable.getValueAt(selectedRow, 4));

                    // Clear the weather details panel when a new row is selected
                    weatherDetailsTextArea.setText("");
                    updateWeatherDetails(locationField.getText());
                }
                isSelectionChanging = false;  // Reset the flag
            }
        });

        setSize(800, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void startTripsUpdateTimer(int userID) {
        Timer timer = new Timer(10000, (ActionEvent e) -> {
            fetchAndDisplayTrips(userID);
        });
        timer.start();
    }

    private void handleExpressInterestResponse(HttpResponse<String> response) {
        int statusCode = response.statusCode();
        if (statusCode == 200) {
            // Successful response
            JsonObject jsonResponse = JsonParser.parseString(response.body()).getAsJsonObject();
            String status = jsonResponse.get("status").getAsString();
            if ("success".equals(status)) {
                JOptionPane.showMessageDialog(this, "Expressed interest successfully!\n", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                String message = jsonResponse.get("message").getAsString();
                JOptionPane.showMessageDialog(this, message, "Fail", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            // Handle error response
            String errorMessage = "Failed to express interest. HTTP error code: " + statusCode;
            JOptionPane.showMessageDialog(this, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Create GET reest for trips
    private void fetchAndDisplayTrips(int userID) {
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("http://20.115.50.61:8080/Service/get-all-trips?userID=" + userID))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int responseCode = response.statusCode();

            if (responseCode == 200) {
                parseAndDisplayTrips(response.body());
            } else {
                JOptionPane.showMessageDialog(this, "Failed to fetch trips. HTTP error code: " + responseCode, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void parseAndDisplayTrips(String jsonResponse) {
        DefaultTableModel model = (DefaultTableModel) tripsTable.getModel();
        model.setRowCount(0);  // Clear existing rows

        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

        if (jsonObject.has("trips")) {
            JsonArray tripsArray = jsonObject.getAsJsonArray("trips");

            for (int i = 0; i < tripsArray.size(); i++) {
                JsonObject trip = tripsArray.get(i).getAsJsonObject();
                String tripID = trip.get("TripID").getAsString();
                int userID = trip.get("UserID").getAsInt();
                String location = trip.get("Location").getAsString();
                String startDate = trip.get("StartDate").getAsString();
                String endDate = trip.get("EndDate").getAsString();

                model.addRow(new Object[]{tripID, userID, location, startDate, endDate});
            }
        } else {
            // Handle the case where the "trips" key is not present in the response
            JOptionPane.showMessageDialog(this, "Invalid response format: Missing 'trips' key", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateWeatherDetails(String location) {

        //Check if a selection change is in progress
        if (isSelectionChanging) {
            System.out.println("Selection change is in progress, skipping weather update");
            return;
        }
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("http://20.115.50.61:8080/Service/get-weather?location=" + location))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int responseCode = response.statusCode();

            if (responseCode == 200) {
                String jsonResponse = response.body();
                System.out.println("JSON Response: " + jsonResponse);

                // Use SwingUtilities.invokeLater to execute the logic in the event dispatch thread
                SwingUtilities.invokeLater(() -> {
                    // Add a null check before parsing the JSON response
                    if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                        if (jsonObject.has("weatherDetails")) {
                            String weatherDetails = jsonObject.get("weatherDetails").getAsString();

                            // Set weather details in the JTextArea
                            weatherDetailsTextArea.setText(weatherDetails);
                        } else {
                            // Handle the case where the "weatherDetails" key is missing
                            System.err.println("Invalid response format: Missing 'weatherDetails' key");
                        }
                    } else {
                        // Handle the case where the JSON response is null or empty
                        System.err.println("Invalid JSON response: Null or empty");
                    }

                });
            } else {
                System.err.println("Failed to fetch weather details. HTTP error code: " + responseCode);
            }

        } catch (IOException | InterruptedException e) {
            System.err.println("An error occurred while fetching weather information: " + e.getMessage());
        }
    }

    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {

        private static final int DELAY = 500;  // Delay in milliseconds
        private final Timer timer;

        public SimpleDocumentListener(Runnable onChange) {
            this.timer = new Timer(DELAY, e -> onChange.run());
            this.timer.setRepeats(false);  // Execute only once
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            resetTimer();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            resetTimer();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            resetTimer();
        }

        private void resetTimer() {
            timer.restart();
        }
    }
}
