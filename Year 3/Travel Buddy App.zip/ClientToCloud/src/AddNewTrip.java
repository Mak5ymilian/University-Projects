
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class AddNewTrip extends javax.swing.JFrame {

    private boolean locationErrorDisplayed = false;
    private final int userID;

    public AddNewTrip(int userID) {
        initComponents();
        this.userID = userID;

        // Set the current date as the selected date for both date pickers
        StartDate.setDate(Calendar.getInstance().getTime());
        EndDate.setDate(Calendar.getInstance().getTime());

        // Set the minimum selectable date for both date pickers to today
        StartDate.getMonthView().setLowerBound(Calendar.getInstance().getTime());
        EndDate.getMonthView().setLowerBound(Calendar.getInstance().getTime());

        // Add change listeners to the date pickers to check for future dates
        StartDate.addActionListener(e -> validateDates());
        EndDate.addActionListener(e -> validateDates());

        // Initial validation
        validateDates();
    }

    @SuppressWarnings("unchecked")

    private void validateDates() {
        Date startDate = StartDate.getDate();
        Date endDate = EndDate.getDate();

        // Check if the selected dates are in the future
        if (startDate != null && startDate.before(Calendar.getInstance().getTime())) {
            StartDate.setDate(Calendar.getInstance().getTime());
        }

        if (endDate != null && endDate.before(Calendar.getInstance().getTime())) {
            EndDate.setDate(Calendar.getInstance().getTime());
        }
    }
    
    //JSON Request Body
    private static String buildJsonRequestBody(int userID, String location, Date startDate, Date endDate) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("User ID", userID);
        jsonObject.addProperty("Location", location);
        jsonObject.addProperty("Start Date", dateFormat.format(startDate));
        jsonObject.addProperty("End Date", dateFormat.format(endDate));
        return jsonObject.toString();
    }

    private void locationFocusLost(java.awt.event.FocusEvent evt) {
        if (!this.isVisible()) {
            return; // Skip processing if the frame is not visible
        }

        //Capitalise first letter
        String inputLocation = Location.getText();
        if (!inputLocation.isEmpty()) {
            Location.setText(capitalizeFirstLetter(inputLocation));
        }

        // Check for empty location
        if (inputLocation.isEmpty()) {
            // Display pop-up to notify the user to fill the text box
            JOptionPane.showMessageDialog(rootPane, "Please fill in the Location field.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }

        // Check for digits and symbols other than comma
        if (!isValidLocation(inputLocation)) {
            // Display pop-up to notify the user about invalid characters
            JOptionPane.showMessageDialog(rootPane, "Invalid characters in the Location field. Only letters and commas are allowed.", "Input Error", JOptionPane.ERROR_MESSAGE);
            Location.setText(""); // Clear the text field
        }
    }

    private String capitalizeFirstLetter(String input) {
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }

    private boolean isValidLocation(String input) {
        return input.matches("^[a-zA-Z, ]+$");
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        suggestNTText = new javax.swing.JLabel();
        Location = new javax.swing.JTextField();
        submitButton = new javax.swing.JButton();
        goBack = new javax.swing.JLabel();
        suggestNTText1 = new javax.swing.JLabel();
        StartDateText = new javax.swing.JLabel();
        EndDateText = new javax.swing.JLabel();
        StartDate = new org.jdesktop.swingx.JXDatePicker();
        EndDate = new org.jdesktop.swingx.JXDatePicker();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Title.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        Title.setText("TravelBuddyFinder");
        jPanel1.add(Title, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        suggestNTText.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        suggestNTText.setText("Add New Trip");
        suggestNTText.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        suggestNTText.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        suggestNTText.setVerifyInputWhenFocusTarget(false);
        jPanel1.add(suggestNTText, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        // Adds a FocusListener to the Location text field
        Location.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                locationFocusLost(evt);
            }
        });
        jPanel1.add(Location, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 118, 257, -1));

        submitButton.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        submitButton.setText("SUBMIT");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
        jPanel1.add(submitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 236, -1, -1));

        goBack.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        goBack.setText("Go Back");
        goBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                goBackMouseClicked(evt);
            }
        });
        jPanel1.add(goBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 269, -1, -1));

        suggestNTText1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        suggestNTText1.setText("Location :");
        jPanel1.add(suggestNTText1, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 117, -1, -1));

        StartDateText.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        StartDateText.setText("Start Date :");
        jPanel1.add(StartDateText, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 158, -1, -1));

        EndDateText.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        EndDateText.setText("End Date :");
        jPanel1.add(EndDateText, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 200, -1, -1));
        jPanel1.add(StartDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 158, 257, -1));
        jPanel1.add(EndDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 200, 257, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // Submit Button:
        String location = Location.getText();
        Date startDate = StartDate.getDate();
        Date endDate = EndDate.getDate();
        
        //Location validity check
        if (location.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in the Location field.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidLocation(location)) {
            if (!locationErrorDisplayed) {
                JOptionPane.showMessageDialog(rootPane, "Invalid characters in the Location field. Only letters and commas are allowed.", "Input Error", JOptionPane.ERROR_MESSAGE);
                locationErrorDisplayed = true;
            }
            Location.setText("");
            return;
        }
        
        //Send POST Request
        try {
            String newTripURL = "http://20.115.50.61:8080/Service/new-trip";
            String requestBody = buildJsonRequestBody(userID, location, startDate, endDate);
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(newTripURL))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                JsonObject jsonResponse = JsonParser.parseString(response.body()).getAsJsonObject();
                String status = jsonResponse.get("status").getAsString();

                if (!"success".equals(status)) {
                    if ("fail".equals(status)) {
                        String message = jsonResponse.get("message").getAsString();
                        JOptionPane.showMessageDialog(rootPane, message);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Unexpected status: " + status);
                    }
                } else {
                    String tripID = jsonResponse.get("TripID").getAsString();
                    String message = jsonResponse.get("message").getAsString();

                    // Check if the "message" is a success message
                    if ("Added Trip Successfully!".equals(message)) {
                        String jlocation = jsonResponse.get("Location").getAsString();
                        String jstartDatee = jsonResponse.get("StartDate").getAsString();
                        String jendDatee = jsonResponse.get("EndDate").getAsString();
                        String weatherInfo = jsonResponse.get("Current Weather").getAsString();

                        // Display pop-up with trip details and weather information
                        String successMessage = String.format(
                                "Added Trip Successfully!\nTrip ID: %s\nLocation: %s\nStart Date: %s\nEnd Date: %s\nCurrent Weather: %s",
                                tripID, jlocation, jstartDatee, jendDatee, weatherInfo);

                        JOptionPane.showMessageDialog(rootPane, successMessage, "Trip Details", JOptionPane.INFORMATION_MESSAGE);

                        // Go back to home screen
                        new Home(userID).setVisible(true);
                        this.setVisible(false);
                    } else {
                        // Handle other success messages
                        JOptionPane.showMessageDialog(rootPane, message);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Failed to Create a new Trip. Please try again later.");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_submitButtonActionPerformed

    private void goBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_goBackMouseClicked
        //Go Back button:
        if (this.isVisible()) {
            this.setVisible(false);
            new Home(userID).setVisible(true);
        }

    }//GEN-LAST:event_goBackMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private org.jdesktop.swingx.JXDatePicker EndDate;
    private javax.swing.JLabel EndDateText;
    private javax.swing.JTextField Location;
    private org.jdesktop.swingx.JXDatePicker StartDate;
    private javax.swing.JLabel StartDateText;
    private javax.swing.JLabel Title;
    private javax.swing.JLabel goBack;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel suggestNTText;
    private javax.swing.JLabel suggestNTText1;
    // End of variables declaration//GEN-END:variables
}
