
public class Home extends javax.swing.JFrame {

    private final int userId;

    public Home(int userId) {
        initComponents();
        this.userId = userId;
        userID.setText("Logged in as User ID: " + userId);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        userID = new javax.swing.JLabel();
        NewTrip = new javax.swing.JButton();
        ViewYourTrips = new javax.swing.JButton();
        ViewAllTrips = new javax.swing.JButton();
        SignOut = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Title.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        Title.setText("TravelBuddyFinder");
        jPanel1.add(Title, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        userID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userID.setToolTipText("");
        userID.setFocusable(false);
        userID.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(userID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 250, 30));

        NewTrip.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        NewTrip.setText("Add New Trip");
        NewTrip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewTripActionPerformed(evt);
            }
        });
        jPanel1.add(NewTrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 188, 35));

        ViewYourTrips.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        ViewYourTrips.setText("View Your Trips");
        ViewYourTrips.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewYourTripsActionPerformed(evt);
            }
        });
        jPanel1.add(ViewYourTrips, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 188, 35));

        ViewAllTrips.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        ViewAllTrips.setText("View All Trips");
        ViewAllTrips.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewAllTripsActionPerformed(evt);
            }
        });
        jPanel1.add(ViewAllTrips, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 188, 35));

        SignOut.setText("Sign Out");
        SignOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignOutActionPerformed(evt);
            }
        });
        jPanel1.add(SignOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NewTripActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewTripActionPerformed
        //Suggest New Trip Button:
        new AddNewTrip(userId).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_NewTripActionPerformed

    private void ViewYourTripsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewYourTripsActionPerformed
        // View Your Trip Button:
        new ViewUserTrips(userId).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ViewYourTripsActionPerformed

    private void ViewAllTripsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewAllTripsActionPerformed
        // View All Trip Button:
        new ViewAllTrips(userId).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ViewAllTripsActionPerformed

    private void SignOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignOutActionPerformed
        // Sign Out Button
        new Login().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_SignOutActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton NewTrip;
    private javax.swing.JButton SignOut;
    private javax.swing.JLabel Title;
    private javax.swing.JButton ViewAllTrips;
    private javax.swing.JButton ViewYourTrips;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel userID;
    // End of variables declaration//GEN-END:variables
}
