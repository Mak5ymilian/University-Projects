
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.awt.HeadlessException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.NoSuchAlgorithmException;
import javax.swing.JOptionPane;

public class Register extends javax.swing.JFrame {

    public Register() {
        initComponents();
    }

    @SuppressWarnings("unchecked")

    // Check if the provided email is in a valid format
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }
    
    //Create JSON Request
    private static String buildJsonRequestBody(String email, String hashedPassword) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("Email", email);
        jsonObject.addProperty("Password", hashedPassword);
        return jsonObject.toString();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        email_text = new javax.swing.JLabel();
        jEmail = new javax.swing.JTextField();
        password_text = new javax.swing.JLabel();
        jRegister = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPassword = new javax.swing.JPasswordField();
        password_text1 = new javax.swing.JLabel();
        jPassword1 = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Title.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        Title.setText("TravelBuddyFinder");
        jPanel1.add(Title, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, 66));

        email_text.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        email_text.setText("Email :");
        jPanel1.add(email_text, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 60, -1));
        jPanel1.add(jEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 253, 36));

        password_text.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        password_text.setText("Password :");
        jPanel1.add(password_text, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, -1, -1));

        jRegister.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jRegister.setText("Register");
        jRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(jRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 127, 73));

        jLabel2.setText("Already Have an Account? Login");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 180, -1));
        jPanel1.add(jPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 253, 36));

        password_text1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        password_text1.setText("Confirm Password :");
        jPanel1.add(password_text1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));
        jPanel1.add(jPassword1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 254, 36));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        this.setVisible(false);
        new Login().setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegisterActionPerformed
        //Register Button
        String email = jEmail.getText();
        String password = jPassword.getText();
        String password1 = jPassword1.getText();
        
        //Field validity Check
        if (password.isEmpty() && password1.isEmpty() && email.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in all fields.");
            return;
        } // Check if the email is empty
        else if (email.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in the Email field.");
            return;
        } //Check if email is in valid format
        else if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(rootPane, "Please enter a valid email address.");
            return;
        } // Check if the password is empty
        else if (password.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in the Password field.");
            return;
        } // Check if the retyped password is empty
        else if (password1.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Please fill in the Confirm Password field.");
            return;
        }

        //If two password fields match:
        if (password.equals(password1)) {
            try {

                // Hash the password
                String hashedPassword = PasswordHasher.hashString(password);

                String registrationURL = "http://20.115.50.61:8080/Service/register";
                
                //Send POST Request
                String requestBody = buildJsonRequestBody(email, hashedPassword);

                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(registrationURL))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() == 200) {
                    JsonObject jsonResponse = JsonParser.parseString(response.body()).getAsJsonObject();
                    String status = jsonResponse.get("status").getAsString();

                    if ("success".equals(status)) {
                        JOptionPane.showMessageDialog(rootPane, "Registered Successfully!");
                        this.setVisible(false);
                        new Login().setVisible(true);
                    } else {
                        String message = jsonResponse.get("message").getAsString();
                        JOptionPane.showMessageDialog(rootPane, message);
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Failed to Register. Please try again later.");
                }
            } catch (JsonSyntaxException | HeadlessException | IOException | InterruptedException | NoSuchAlgorithmException e) {
                JOptionPane.showMessageDialog(rootPane, "Failed to Register. Please check your internet connection or contact support");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Password Doesn't match. Try Again");
        }
    }//GEN-LAST:event_jRegisterActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Title;
    private javax.swing.JLabel email_text;
    private javax.swing.JTextField jEmail;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPassword;
    private javax.swing.JPasswordField jPassword1;
    private javax.swing.JButton jRegister;
    private javax.swing.JLabel password_text;
    private javax.swing.JLabel password_text1;
    // End of variables declaration//GEN-END:variables
}
