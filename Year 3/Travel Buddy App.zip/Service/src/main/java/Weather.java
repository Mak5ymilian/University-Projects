
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 *
 * @author maksm
 */
public class Weather {

    private static final String GOOGLE_GEOCODING_API_KEY = "AIzaSyA4euIi4uKIuHhdsxtgMIcIt9zFlpbGF7c";

    public String getWeather(String location) throws WeatherException {
        try {
            String geocodingUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=" + location + "&key=" + GOOGLE_GEOCODING_API_KEY;

            HttpClient geocodingClient = HttpClient.newHttpClient();
            HttpRequest geocodingRequest = HttpRequest.newBuilder()
                    .uri(URI.create(geocodingUrl))
                    .build();

            HttpResponse<String> geocodingResponse = geocodingClient.send(geocodingRequest, HttpResponse.BodyHandlers.ofString());

            if (geocodingResponse.statusCode() == 200) {
                // Parse Geocoding API Response
                JsonObject geocodingJson = JsonParser.parseString(geocodingResponse.body()).getAsJsonObject();
                JsonArray georesults = geocodingJson.getAsJsonArray("results");

                if (georesults.size() > 0) {
                    JsonObject locationInfo = georesults.get(0).getAsJsonObject().getAsJsonObject("geometry").getAsJsonObject("location");
                    String latitude = locationInfo.get("lat").getAsString();
                    String longitude = locationInfo.get("lng").getAsString();

                    // Make weather API request
                    HttpRequest weatherRequest = HttpRequest.newBuilder()
                            .uri(URI.create("https://weatherapi-com.p.rapidapi.com/current.json?q=" + latitude + "%2C" + longitude))
                            .header("X-RapidAPI-Key", "552c7a73f3mshcbd301e0c0264dcp12e8bfjsn63c13553b86e")
                            .header("X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com")
                            .method("GET", HttpRequest.BodyPublishers.noBody())
                            .build();

                    HttpResponse<String> weatherResponse = HttpClient.newHttpClient().send(weatherRequest, HttpResponse.BodyHandlers.ofString());

                    if (weatherResponse.statusCode() == 200) {
                        // Parse Weather API Response
                        JsonObject weatherJson = JsonParser.parseString(weatherResponse.body()).getAsJsonObject();
                        JsonObject current = weatherJson.getAsJsonObject("current");

                        // Get relevant data
                        String temperatureCelsius = current.get("temp_c").getAsString();
                        String conditionText = current.getAsJsonObject("condition").get("text").getAsString();

                        // Return the relevant data
                        return "Temperature (°C): " + temperatureCelsius + "\nCondition: " + conditionText;
                    } else {
                        throw new WeatherException("Failed to get weather information. HTTP response code: " + weatherResponse.statusCode());
                    }
                } else {
                    throw new WeatherException("No results found from Geocoding API");
                }
            } else {
                throw new WeatherException("Failed to get Geocoding API response. HTTP response code: " + geocodingResponse.statusCode());
            }
        } catch (WeatherException | JsonSyntaxException | IOException | InterruptedException e) {
            throw new WeatherException("An error occurred while fetching weather information: " + e.getMessage());
        }
    }
}
