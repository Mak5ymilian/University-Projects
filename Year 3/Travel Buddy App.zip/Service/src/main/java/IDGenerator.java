
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 *
 * @author maksm
 */
public class IDGenerator {

    // API Key for Random.org
    private static final String API_KEY = "89457900-3df2-4f5b-a6a0-1d856ada801d";

    public JsonObject getUserID() throws IOException, InterruptedException {
        String url = "https://api.random.org/json-rpc/4/invoke";

        String jsonInputString = "{\"jsonrpc\": \"2.0\", \"method\": \"generateIntegers\", "
                + "\"params\": {\"apiKey\": \"" + API_KEY + "\", \"n\": 1, \"min\": 1, \"max\": 99999, "
                + "\"replacement\": false, \"base\": 10, \"pregeneratedRandomization\": null}, \"id\": 15781}";

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("api-key", API_KEY)
                .POST(HttpRequest.BodyPublishers.ofString(jsonInputString))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return parseUserIDFromJson(response.body());
        } else {
            throw new IOException("Failed to get random user ID from external API. HTTP response code: " + response.statusCode());
        }
    }

    private JsonObject parseUserIDFromJson(String jsonResponse) {
        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
        JsonObject resultObject = jsonObject.getAsJsonObject("result");
        JsonArray dataArray = resultObject.getAsJsonObject("random").getAsJsonArray("data");

        if (dataArray.size() > 0) {
            JsonObject result = new JsonObject();
            result.addProperty("User ID", dataArray.get(0).getAsInt());
            return result;
        } else {
            throw new NumberFormatException("No user ID found in the JSON response");
        }
    }

    public JsonObject getTripID() throws IOException, InterruptedException {
        String url = "https://api.random.org/json-rpc/4/invoke";

        String jsonInputString = "{\"jsonrpc\": \"2.0\", \"method\": \"generateStrings\", "
                + "\"params\": {\"apiKey\": \"" + API_KEY + "\", \"n\": 1, \"length\": 8, \"characters\": \"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\", "
                + "\"replacement\": false, \"pregeneratedRandomization\": null}, \"id\": 15781}";

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("api-key", API_KEY)
                .POST(HttpRequest.BodyPublishers.ofString(jsonInputString))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return parseTripIDFromJson(response.body());
        } else {
            throw new IOException("Failed to get random trip ID. HTTP response code: " + response.statusCode());
        }
    }

    private JsonObject parseTripIDFromJson(String jsonResponse) {
        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
        JsonObject resultObject = jsonObject.getAsJsonObject("result");
        JsonArray dataArray = resultObject.getAsJsonObject("random").getAsJsonArray("data");

        if (dataArray.size() > 0) {
            JsonObject result = new JsonObject();
            result.addProperty("Trip ID", dataArray.get(0).getAsString());
            return result;
        } else {
            throw new NumberFormatException("No trip ID found in the JSON response");
        }
    }
}
