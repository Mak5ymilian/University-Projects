
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.stream.Collectors;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet(urlPatterns = {"/express-interest"})
public class ExpressInterestServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");

        try {
            // Read JSON Data from request
            String jsonData = request.getReader().lines().collect(Collectors.joining());
            System.out.println("Received JSON Data: " + jsonData);

            // Parse JSON Data from client request to express interest
            JsonObject jsonInput = JsonParser.parseString(jsonData).getAsJsonObject();

            // Directly get "UserID" and "TripID" from the parsed JSON
            JsonElement userIDElement = jsonInput.get("UserID");
            JsonElement tripIDElement = jsonInput.get("TripID");

            // Check if the elements are present and are primitives
            if (userIDElement != null && userIDElement.isJsonPrimitive() && tripIDElement != null && tripIDElement.isJsonPrimitive()) {
                String userID = userIDElement.getAsString();
                String tripID = tripIDElement.getAsString();

                // Convert the strings to JSON objects
                JsonObject userIDJson = new JsonObject();
                userIDJson.addProperty("UserID", userID);

                JsonObject tripIDJson = new JsonObject();
                tripIDJson.addProperty("TripID", tripID);

                JsonObject interestResult = new Database().userExpressedInterestCheck(userIDJson, tripIDJson);

                // Check if the user has already expressed interest in the trip
                if (interestResult.has("status") && interestResult.get("status").getAsString().equals("fail")) {
                    out.println(interestResult);
                    out.flush();
                    System.out.println(interestResult);
                } else {
                    // User has not expressed interest, proceed with expressing interest
                    JsonObject expressInterestResult = new Database().addInterest(userIDJson, tripIDJson);

                    // Check if expressing interest was successful
                    if (expressInterestResult.has("status") && expressInterestResult.get("status").getAsString().equals("success")) {
                        out.println(expressInterestResult);
                        out.flush();
                        System.out.println(expressInterestResult);
                    } else {
                        // Handle the case where expressing interest fails
                        out.println("{\"status\": \"error\", \"message\": \"Failed to express interest\"}");
                        out.flush();
                    }
                }
            } else {
                // Handle the case where "UserID" or "TripID" is missing or not a primitive
                out.println("{\"status\": \"error\", \"message\": \"Invalid input format\"}");
                out.flush();
            }
        } catch (JsonSyntaxException | IOException | SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject errorJson = new JsonObject();
            errorJson.addProperty("status", "error");
            errorJson.addProperty("message", "Internal Server Error");
            out.println(errorJson);
            out.flush();
        }
    }
}
