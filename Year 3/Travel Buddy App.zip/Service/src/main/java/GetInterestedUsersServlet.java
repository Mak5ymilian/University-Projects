
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet(urlPatterns = {"/get-interested-users"})
public class GetInterestedUsersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        try {

            // Retrieve user ID from URL parameter
            String tripIDParam = request.getParameter("tripID");

            if (tripIDParam == null) {
                throw new NumberFormatException("Trip ID parameter is null or not present in the request.");
            }

            // Create a JsonObject with the userID
            JsonObject tripIDJson = new JsonObject();
            tripIDJson.addProperty("TripID", tripIDParam);

            if (!tripIDJson.isEmpty()) {
                JsonObject interestedUsers = new Database().getInterestedUsers(tripIDJson);
                out.println(interestedUsers);
                out.flush();
                System.out.println(interestedUsers);
            }
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("{\"status\": \"error\", \"message\": \"Internal Server Error\"}");
            out.flush();
        }
    }
}
