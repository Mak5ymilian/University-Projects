
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.stream.Collectors;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet("/new-trip")
public class NewTripServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject failResponse = new JsonObject();
        response.setContentType("application/json");
        try {
            // Read JSON data from request
            String jsonData = request.getReader().lines().collect(Collectors.joining());

            // Parse Json data from client request to get trip data
            JsonObject jsonTripData = JsonParser.parseString(jsonData).getAsJsonObject();

            //Parse location details from client JSON request
            String location = jsonTripData.get("Location").getAsString();

            //Get Weather information from the parsed location
            String weatherinfo = new Weather().getWeather(location);
            // Check if location or weather information is missing
            if (weatherinfo == null) {
                failResponse.addProperty("status", "fail");
                failResponse.addProperty("message", "Failed to Add Trip! Invalid or missing Location.");
                out.println(failResponse.toString());
                out.flush();
            } else {
                JsonObject tripID = new IDGenerator().getTripID();
                jsonTripData.addProperty("Trip ID", tripID.get("Trip ID").getAsString());

                JsonObject result = new Database().storeTrip(jsonTripData);

                if (result.has("status") && result.get("status").getAsString().equals("success")) {
                    //Send success JSON rsponse to client
                    result.addProperty("Current Weather", weatherinfo);
                    out.println(result.toString());
                    System.out.println(result);
                    out.flush();
                } else {
                    //Send fail JSON response to client
                    out.println(result.toString());
                    out.flush();
                }
            }
        } catch (JsonSyntaxException | IOException | WeatherException | InterruptedException | SQLException e) {
            //Handle JSON parsing or IO exceptions
            failResponse.addProperty("status", "fail");
            failResponse.addProperty("message", "Failed to Add Trip! JSON parsing or IO exception.");
            out.println(failResponse.toString());
            out.flush();
            System.out.println("Error: " + e.getMessage());
        }
    }
}
