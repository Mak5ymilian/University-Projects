
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet(name = "WeatherServlet", urlPatterns = {"/get-weather"})
public class WeatherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");

        try (PrintWriter out = response.getWriter()) {
            // Get Location from JSON parameter
            String location = request.getParameter("location");

            // Call the Weather class to get weather details based on the location
            String weatherDetails = new Weather().getWeather(location);

            // Send the weather details as the response
            out.print("{\"weatherDetails\":\"" + weatherDetails + "\"}");

        } catch (WeatherException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("Failed to fetch weather information: " + e.getMessage());
        }
    }
}
