
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.stream.Collectors;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        try {
            //Read JSON data from client request
            String jsonData = request.getReader().lines().collect(Collectors.joining());
            System.out.println(jsonData);

            // Parse the JSON reg data from the client request to get user details
            JsonObject jsonReg = JsonParser.parseString(jsonData).getAsJsonObject();

            Database db = new Database();
            // Check if client's email already exists
            JsonObject existingEmailResult = db.existingEmailCheck(jsonReg);

            //Check if client's email already exists
            if (existingEmailResult.has("status") && existingEmailResult.get("status").getAsString().equals("fail")) {
                // Email already exists, send failure response to the client
                out.println(existingEmailResult);
                out.flush();
                System.out.println(existingEmailResult);
            } else {
                //Get UserID from IDGenerator               
                JsonObject userID = new IDGenerator().getUserID();

                // Add user ID to the JSON object
                jsonReg.add("UserID", userID.get("User ID"));

                //Store client reg details to database
                JsonObject registrationResult = db.storeUser(jsonReg);

                // Send success repsonse to the client
                out.println(registrationResult);
                out.flush();
                System.out.println(registrationResult);
            }
        } catch (JsonSyntaxException | IOException | InterruptedException | SQLException e) {
            //Send failure response to the client
            JsonObject failResponse = new JsonObject();
            failResponse.addProperty("status", "fail");
            failResponse.addProperty("message", "Failed to register user!");
            out.println(failResponse);
            out.flush();
            System.out.println(failResponse);
        }
    }
}
