
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.stream.Collectors;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        try {
            // Read JSON data from request
            String jsonData = request.getReader().lines().collect(Collectors.joining());

            // Parse Json data from client request to get email and password
            JsonObject jsonLogin = JsonParser.parseString(jsonData).getAsJsonObject();

            JsonObject loginResult = new Database().loginUser(jsonLogin);
            // Authenticate the user if email and password match
            if (loginResult.has("UserID")) {
                out.println(loginResult);
                out.flush();
                System.out.println(loginResult);
            } else {
                // Authentication failed
                out.println(loginResult);
                out.flush();
                System.out.println(loginResult);
            }
        } catch (IOException | SQLException ex) {
            JsonObject failResponse = new JsonObject();
            failResponse.addProperty("status", "fail");
            failResponse.addProperty("message", "Failed to process login request");
            out.println(failResponse);
            out.flush();
            System.out.println(failResponse);
        }
    }
}
