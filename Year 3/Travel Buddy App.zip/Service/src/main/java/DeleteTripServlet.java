
import com.google.gson.JsonObject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 *
 * @author maksm
 */
@WebServlet(urlPatterns = {"/delete-trip"})
public class DeleteTripServlet extends HttpServlet {

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JsonObject deleteTripJSON = new JsonObject();

        try {
            // Read tripID from the request
            String tripID = request.getParameter("tripID");

            // Check if tripID is provided
            if (tripID == null || tripID.isEmpty()) {
                // Send HTTP 400
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                return;
            }

            System.out.println("Received Request to delete trip: " + tripID);
            deleteTripJSON.addProperty("TripID", tripID);

            Database database = new Database();
            JsonObject result = database.deleteTrip(deleteTripJSON);

            response.setContentType("application/json");

            if (result.get("status").getAsString().equals("success")) {
                response.setStatus(HttpServletResponse.SC_OK);
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject failResponse = new JsonObject();
            failResponse.addProperty("status", "fail");
            failResponse.addProperty("message", "Unexpected error.");
            failResponse.addProperty("details", e.getMessage());
            try (PrintWriter out = response.getWriter()) {
                out.print(failResponse);
            }
        }
    }
}
