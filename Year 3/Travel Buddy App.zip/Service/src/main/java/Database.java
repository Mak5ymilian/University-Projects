
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author maksm
 */
public class Database {

    Connection con;

    //Connects to the database
    public Connection Connect() {
        try {
            //Loads DB Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "root");
            System.out.println("Connected to Database");
            return con;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Failed to connect to Database");
            return null;
        }
    }

    //Closes communication with the database
    public void Close() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Database connection closed");
            }
        } catch (SQLException e) {
            System.out.println("Failed to close the database connection: " + e.getMessage());
        }
    }

    //Stores user into the database during registration
    public JsonObject storeUser(JsonObject regData) throws SQLException {
        Connection connect = Connect();
        JsonObject result = new JsonObject();
        try {
            String sql = "INSERT INTO users (UserID, Email, Password) VALUES (?, ?, ?)";

            //Parse cleint's reg from JSON and store in the database
            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setInt(1, regData.get("UserID").getAsInt());
                preparedStatement.setString(2, regData.get("Email").getAsString());
                preparedStatement.setString(3, regData.get("Password").getAsString());

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("User stored in database successfully");
                    result.addProperty("status", "success");
                    result.addProperty("message", "User registered successfully!");
                } else {
                    System.out.println("Failed to store user in the database");
                    result.addProperty("status", "fail");
                    result.addProperty("message", "Failed to register user!.");
                }
            }
        } finally {
            Close();
        }
        return result;
    }

    //Check to see if an email exists in database when registering
    public JsonObject existingEmailCheck(JsonObject jsonEmail) throws SQLException {
        Connection connect = Connect();
        JsonObject result = new JsonObject();
        try {
            //Extract email from JSON object
            String email = jsonEmail.get("Email").getAsString();

            String sql = "SELECT COUNT(*) FROM users WHERE Email = ?";

            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, email);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) { //Check if more than one email exists
                        int count = resultSet.getInt(1);

                        //Send failure response if email exists
                        if (count > 0) {
                            result.addProperty("status", "fail");
                            result.addProperty("message", "Email already exists. Please use a different one.");
                        }
                    }
                }
            }
        } finally {
            Close();
        }
        return result;
    }

    //Logs user in to the database if the password matches
    public JsonObject loginUser(JsonObject userLoginJSON) throws SQLException {
        Connection connect = Connect();
        JsonObject result = new JsonObject();
        try {
            String sql = "SELECT UserID FROM users WHERE Email = ? AND Password = ?";

            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, userLoginJSON.get("Email").getAsString());
                preparedStatement.setString(2, userLoginJSON.get("Password").getAsString());

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // If the result set has at least one row, return success JSON containing UserID
                        result.addProperty("status", "success");
                        result.addProperty("message", "Login Successful!");
                        result.addProperty("UserID", resultSet.getInt("UserID"));
                        return result;
                    } else {
                        // If the result set is empty, return a JSON object with a status indicating authentication failure                     
                        result.addProperty("status", "fail");
                        result.addProperty("message", "Invalid email or password!");
                        return result;
                    }
                }
            }
        } finally {
            Close();
        }
    }

    public JsonArray viewAllTrips(JsonObject userID) throws SQLException {
        Connection connect = Connect();
        JsonArray tripsArray = new JsonArray();

        try {
            if (userID == null || userID.get("UserID") == null) {
                System.out.println("UserID is null or not present in the JSON object.");
                return tripsArray; // Return an empty array or handle as appropriate
            }

            // Query trips excluding those associated with the provided user ID and expired trips
            String sql = "SELECT * FROM trips WHERE UserID != ? AND STR_TO_DATE(EndDate, '%d-%m-%Y') >= CURRENT_DATE ";

            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, userID.get("UserID").getAsString());

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        JsonObject tripJson = new JsonObject();
                        tripJson.addProperty("TripID", resultSet.getString("TripID"));
                        tripJson.addProperty("UserID", resultSet.getInt("UserID"));
                        tripJson.addProperty("Location", resultSet.getString("Location"));
                        tripJson.addProperty("StartDate", resultSet.getString("StartDate"));
                        tripJson.addProperty("EndDate", resultSet.getString("EndDate"));
                        tripsArray.add(tripJson);
                    }
                }
            }
        } finally {
            Close();
        }
        return tripsArray;
    }

//Stores client's trip into the database
    public JsonObject storeTrip(JsonObject tripDetails) throws SQLException {
        Connection connect = Connect();
        JsonObject result = new JsonObject();
        try {
            String sql = "INSERT INTO trips (TripID, UserID, Location, StartDate, EndDate) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, tripDetails.get("Trip ID").getAsString());
                preparedStatement.setInt(2, tripDetails.get("User ID").getAsInt());
                preparedStatement.setString(3, tripDetails.get("Location").getAsString());
                preparedStatement.setString(4, tripDetails.get("Start Date").getAsString());
                preparedStatement.setString(5, tripDetails.get("End Date").getAsString());

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Stored Trip Successfully in the Database");
                    result.addProperty("status", "success");
                    result.addProperty("message", "Added Trip Successfully!");
                    result.addProperty("TripID", tripDetails.get("Trip ID").getAsString());
                    result.addProperty("UserID", tripDetails.get("User ID").getAsInt());
                    result.addProperty("Location", tripDetails.get("Location").getAsString());
                    result.addProperty("StartDate", tripDetails.get("Start Date").getAsString());
                    result.addProperty("EndDate", tripDetails.get("End Date").getAsString());
                    return result;
                } else {
                    System.out.println("Failed to Store Trip in the Database");
                    result.addProperty("status", "fail");
                    result.addProperty("message", "Failed to Store Trip in the Database");
                    return result;
                }
            }
        } finally {
            Close();
        }
    }

    public JsonArray ViewUserTrips(JsonObject userID) throws SQLException {
        Connection connect = Connect();
        JsonArray tripsArray = new JsonArray();

        //Get users trips from database
        try {

            String sql = "SELECT * FROM trips WHERE UserID = ?";
            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, userID.get("UserID").getAsString());

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        //Create JSON object for each trip
                        JsonObject tripJson = new JsonObject();
                        tripJson.addProperty("TripID", resultSet.getString("TripID"));
                        tripJson.addProperty("Location", resultSet.getString("Location"));
                        tripJson.addProperty("StartDate", resultSet.getString("StartDate"));
                        tripJson.addProperty("EndDate", resultSet.getString("EndDate"));

                        //Add trip object to the array
                        tripsArray.add(tripJson);
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("Failed to retrieve trips from the database.");
            System.out.println("SQL Exception: " + ex.getMessage());
        } finally {
            Close();
        }
        return tripsArray;
    }

    public JsonObject userExpressedInterestCheck(JsonObject userID, JsonObject tripID) throws SQLException {
        Connection connection = Connect();
        JsonObject result = new JsonObject();

        try {
            String sql = "SELECT COUNT(*) FROM interests WHERE UserID = ? AND TripID = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, userID.get("UserID").getAsString());
                preparedStatement.setString(2, tripID.get("TripID").getAsString());

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);

                        if (count > 0) {
                            // User has expressed interest
                            result.addProperty("status", "fail");
                            result.addProperty("message", "Already expressed interest for trip: " + tripID.get("TripID").getAsString());
                        }
                    }
                }
            }
        } finally {
            Close();
        }

        return result;
    }

    //Add user's interest to a trip
    public JsonObject addInterest(JsonObject userID, JsonObject tripID) throws SQLException {
        Connection connection = Connect();
        JsonObject result = new JsonObject();
        try {
            String sql = "INSERT INTO interests (UserID, TripID) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, userID.get("UserID").getAsString());
                preparedStatement.setString(2, tripID.get("TripID").getAsString());

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Interest stored in database successfully");
                    result.addProperty("status", "success");
                    result.addProperty("message", "Expressed interest for Trip: " + tripID + "\"}");
                    return result;
                } else {
                    System.out.println("Failed to store interest in the database");
                    result.addProperty("status", "fail");
                    result.addProperty("message", "Already Expressed interest for this trip");
                    return result;
                }
            }
        } finally {
            Close();
        }
    }

    public JsonObject getInterestedUsers(JsonObject tripID) throws SQLException {
        Connection connection = Connect();
        JsonArray interestedUsers = new JsonArray();

        try {
            String sql = "SELECT UserID FROM interests WHERE TripID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, tripID.get("TripID").getAsString());

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        int userID = resultSet.getInt("UserID");
                        interestedUsers.add(userID);
                    }
                }
            }
        } finally {
            Close();
        }

        // Create a single JsonObject with the interestedUsers array
        JsonObject resultJson = new JsonObject();
        resultJson.addProperty("status", "success");
        resultJson.add("interestedUsers", interestedUsers);

        return resultJson;
    }

    public JsonObject deleteTrip(JsonObject tripID) throws SQLException {
        Connection connect = Connect();
        JsonObject result = new JsonObject();

        try {
            // Start a transaction
            connect.setAutoCommit(false);

            // Delete related records in the interests table
            deleteInterestRecords(tripID);

            // Delete the trip record
            String sql = "DELETE FROM trips WHERE TripID = ?";
            try (PreparedStatement preparedStatement = connect.prepareStatement(sql)) {
                preparedStatement.setString(1, tripID.get("TripID").getAsString());
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Trip deleted from database successfully");
                    result.addProperty("status", "success");
                } else {
                    System.out.println("Failed to delete trip from the database");
                    result.addProperty("status", "fail");
                }
            }

            // Commit the transaction if everything is successful
            connect.commit();
        } catch (SQLException e) {
            // Roll back the transaction in case of an error
            connect.rollback();
            result.addProperty("status", "fail");
            throw e;
        } finally {
            // Set auto commit to true to end the transaction
            connect.setAutoCommit(true);
            Close();
        }

        return result;
    }

// Deletes related records in the interests table
    private void deleteInterestRecords(JsonObject tripID) throws SQLException {
        Connection connect = Connect();
        try {
            String deleteInterestsSql = "DELETE FROM interests WHERE TripID = ?";
            try (PreparedStatement deleteInterestsStatement = connect.prepareStatement(deleteInterestsSql)) {
                deleteInterestsStatement.setString(1, tripID.get("TripID").getAsString());
                int interestsRowsAffected = deleteInterestsStatement.executeUpdate();
                System.out.println("Deleted " + interestsRowsAffected + " records from interests table");
            }
        } finally {
            Close();
        }
    }
}
