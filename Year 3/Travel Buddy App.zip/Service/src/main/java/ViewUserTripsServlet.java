
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author maksm
 */
@WebServlet(name = "ViewUserTripsServlet", urlPatterns = {"/view-trips"})
public class ViewUserTripsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        try {
            // Retrieve user ID from URL parameter
            String userIDParam = request.getParameter("userID");

            if (userIDParam == null) {
                throw new NumberFormatException("User ID parameter is null or not present in the request.");
            }

            // Create a JsonObject with the userID
            JsonObject userIDJson = new JsonObject();
            userIDJson.addProperty("UserID", userIDParam);

            JsonArray tripsArray = new Database().ViewUserTrips(userIDJson);

            // Send the JSON response to the client
            JsonObject responseJson = new JsonObject();
            responseJson.add("trips", tripsArray);
            out.println(responseJson);
            out.flush();
            System.out.println(responseJson);

        } catch (JsonParseException | SQLException e) {
            // Handle exceptions, log, or send an appropriate error response
            System.out.println("Failed to process the request: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("{\"error\": \"Internal Server Error\"}");
            out.flush();
        }
    }
}
