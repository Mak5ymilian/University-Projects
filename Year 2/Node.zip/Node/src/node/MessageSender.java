package node;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 *
 * @author Home
 */
public class MessageSender {

    private DatagramSocket socket;
    private InetAddress address;
    private final int port;
    private final int capacity;
    private final LinkedList<Job> jobList;
    private String nodeID;
    private final Logger logger;

    public MessageSender(int port, int capacity) {
        this.port = port;
        this.capacity = capacity;
        jobList = new LinkedList<>();
        this.logger = new Logger();
    }
    

    public void startNode(String loadBalancerName, int nodePort) throws IOException {

        try {
            TimeStamp timestamp = new TimeStamp();
            address = InetAddress.getByName(loadBalancerName);
            InetAddress nodeMachineName = InetAddress.getLocalHost();
            String message = ("REG" + "," + nodeMachineName + "," + capacity);
            DatagramPacket reg = new DatagramPacket(message.getBytes(), message.getBytes().length, address, port);
            DatagramSocket sock = new DatagramSocket(nodePort);
            sock.send(reg);
            //socket set to disconnect after sending reg message after 1 min
            sock.setSoTimeout(60000);
            logger.out("Node configured to port " + nodePort + " and capacity " + capacity
                    + "\nREG message sent to load balancer at: "
                    + timestamp.timeStamp());
            this.socket = sock;

            byte[] AckPacketData;
            DatagramPacket ackPacket;
            AckPacketData = new byte[1024];
            ackPacket = new DatagramPacket(AckPacketData, AckPacketData.length);
            sock.receive(ackPacket);
            String ack = new String(AckPacketData, 0, ackPacket.getLength());
            nodeID = ack.split(",")[1];
            logger.out(ack + " at: " + timestamp.timeStamp());
            //socket set to always stay on after aknowledgment
            sock.setSoTimeout(0);

            boolean run = true;
            while (run) {
                byte[] packetData;
                DatagramPacket packet;
                packetData = new byte[1024];
                packet = new DatagramPacket(packetData, packetData.length);
                sock.receive(packet);
                String jobStr = new String(packetData, 0, packet.getLength());
                if ("STOP".equals(packet.toString())){
                    System.exit(0);
                } else {
                Job job = new Job();
                job.getJobFromString(jobStr);
                logger.out("Received jobID: " + job.getJobID() + " With " 
                        + job.getJobTime() + " seconds to process "  +  "at: " + timestamp.timeStamp());
                jobList.add(job);
                //Node threads job processes based of its capacity
                ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(capacity);
                executor.execute(job);
            }
                }
                
            //catches error if a socket is already in use
        } catch (java.net.BindException error) {
            logger.err(error + "\nSocket already in use. "
                    + "Please use another socket");
            System.exit(0);

            //catches error connecting to load balancer
        } catch (java.net.UnknownHostException | java.net.SocketException
                | java.net.SocketTimeoutException error) {
            logger.err(error + "\nUnable to connect to Load Balancer. "
                    + "\nReconnect to loadbalancer using correct IP address and port");
        } finally {
            socket.close();
            System.exit(0);
        }
    }

     public void log(String message) {
        logger.out(message);
    }
    
    public LinkedList<Job> getJobList() {
        return jobList;
    }

    public DatagramSocket getSocket() {
        return socket;
    }

    public InetAddress getAddress() {
        return address;
    }

    public int getPort() {
        return port;
    }

    String getID() {
        return this.nodeID;
    }
}
