package node;

import java.io.IOException;

/**
 *
 * @author Maks
 */
public class Node {

    /**
     * @param args the command line arguments
     */
    private static MessageSender messageSender;

    public static void main(String[] args) throws IOException {
        
        try {
            String loadBalancerHostName = args[0];
            int nodePort = Integer.parseInt(args[1]);
            int loadBalancerPort = Integer.parseInt(args[2]);
            int capacity = Integer.parseInt(args[3]);
            if (nodePort > 65565 || nodePort < 0 && loadBalancerPort > 65565 || loadBalancerPort < 0 ) {
                throw new NumberFormatException();
            }
            messageSender = new MessageSender(loadBalancerPort, capacity);
            messageSender.startNode(loadBalancerHostName, nodePort);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Exception error: " + e);
            System.out.println("Missing Argument");
            System.exit(0);
        } catch (NumberFormatException error) {
            System.out.println("Exception error: " + error);
            System.out.println("2nd and 3rd arguments must be integers > 0 and < 65565!");
            System.exit(0);
        }
    }

    // returns message sender object.
    public static MessageSender getMessageSender() {
        return messageSender;
    }
}
