/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package node;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author maksm
 */
public class TimeStamp {
    
    public String timeStamp() {
        // date
            Date currentDate = new Date();
            SimpleDateFormat timeStamp = new SimpleDateFormat("HH:mm:ss z dd.MM.yyyy");
            return timeStamp.format(currentDate);
    }
}
