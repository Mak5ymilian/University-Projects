package node;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author maks
 */
public final class Logger {
    //Creates array list for log
    public static ArrayList<String> history = new ArrayList<>();
    public static File file;
    
    
    public Logger() {
        file = this.makeFile("Log.txt");
    }
    
     //Creates File
    public File makeFile(String name) {
        return new File(name);
    }
    
    //Saves File
    public static void saveLogFile() {
        try {
            // writes each line to file.
            try (PrintWriter pw = new PrintWriter(new FileOutputStream(file))) {
                // writes each line to file.
                for (String log : history) {
                    pw.println(log);
                }
                // closes pw
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    //Adds String to array list
    private static void historyAdd(String msg) {
        history.add(msg);
        saveLogFile();
    }

    //Prints out to console
    public void out(String msg) {
        historyAdd(msg);
        System.out.print(msg + "\n");
    }
    
    //Prints error code to console
    public void err(String msg) {
        historyAdd(msg);
        System.err.print(msg);
    }
}