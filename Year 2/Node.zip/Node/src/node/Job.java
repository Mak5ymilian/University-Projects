package node;

import java.io.IOException;
import java.net.DatagramPacket;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author maks
 */
public class Job implements Runnable {

    private int jobID;
    private int jobTime;

    public Job() {
        
    }

    public Job(int jobID, int jobTime) {
        this.jobID = jobID;
        this.jobTime = jobTime;
    }

    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public int getJobTime() {
        return jobTime;
    }

    public void setJobTime(int jobTime) {
        this.jobTime = jobTime;
    }
    
    TimeStamp timestamp = new TimeStamp();
    Logger log = new Logger();
    
    
    //Replaces Job message from LB to a String
    public void getJobFromString(String str) {
        str = str.replace("[", "").replace("]", "").replace(" ", "");
        //Assigns Data from String to variables
        this.jobID = Integer.parseInt(str.split(",")[0]);
        this.jobTime = Integer.parseInt(str.split(",")[1]);
    }

    @Override
    public String toString() {
        return "[ " + jobID + ", " + jobTime + " ]";
    }

    //Thread used to process Job messages
    @Override
    public void run() {
        try {
            //Puts thread to sleep based from jobTime
            TimeUnit.SECONDS.sleep(jobTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        log.out("job " + jobID + " completed and sent to loadbalancer at: " + timestamp.timeStamp() );
        Node.getMessageSender().getJobList().remove(this);

        //String created to send finished job packet
        String finData = "FINISH," + jobID + "," + Node.getMessageSender().getID();
        DatagramPacket finPacket = new DatagramPacket(finData.getBytes(), finData.length(),
                Node.getMessageSender().getAddress(), Node.getMessageSender().getPort());
        try {
            //Sends message to loadbalancer
            Node.getMessageSender().getSocket().send(finPacket);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
