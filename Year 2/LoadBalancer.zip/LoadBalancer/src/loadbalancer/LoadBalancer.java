package loadbalancer;

import java.io.IOException;
/**
 *
 * @author Maks
 */
public class LoadBalancer {
    private static int port;
    /**
     * @param args the command line arguments
     */
    //Input port in arguments
    public static void main(String[] args) throws InterruptedException {
        try {
            port = Integer.parseInt(args[0]);
            if (port > 65565 || port < 0) {
                throw new NumberFormatException();
            }
            StartSystem loadbalancer = new StartSystem(port);
            loadbalancer.runBalancer();
        } catch (ArrayIndexOutOfBoundsException | IOException error) {
            error.printStackTrace();
        } catch (NumberFormatException error) {
            error.printStackTrace();
            System.out.println("Port " + port + " must be an integer > 0 and < 65565!");
        }
    }
}
