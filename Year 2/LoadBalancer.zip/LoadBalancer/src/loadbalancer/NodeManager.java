package loadbalancer;

import java.net.InetAddress;
import java.util.LinkedList;

/**
 *
 * @author Maks
 */
public class NodeManager {

    private final LinkedList<Node> availableNodes = new LinkedList<>();
    private final StartSystem system;
    
    
    public NodeManager(StartSystem s) {
        this.system = s;
    }
    public LinkedList<Node> getAvailableNodes() {
        return availableNodes;
    }

    public void registerNode(Node newNode) {
        if (newNode == null) {
            return;
        }
        availableNodes.add(newNode);
    }

    public void registerNode(InetAddress ipAddress, int portNumber, String nodeName, int max) {
        registerNode(new Node(ipAddress, portNumber, nodeName, max));
    }

    //Shows Registered Node to the LoadBalancer
    public void showRegNode() {
        system.log("Registered: " + availableNodes.getLast().getInfo());
    }

    // gets node based on capacity
    public int getBestNodeIndex() {
        int index = 0;
        // sets number to lowest number possible
        int number = -Integer.MAX_VALUE;
        for (int i = 0; i < availableNodes.size(); i++) {
            // sets current to the max jobs - job count which gives the capacity
            int current = availableNodes.get(i).getMaxJobs() - availableNodes.get(i).jobCount;
            // if capcity is higher then number it will set the index to the current node which will give the one with the most current capcity
            if (current > number) {
                number = availableNodes.get(i).getMaxJobs() - availableNodes.get(i).jobCount;
                index = i;
            }
        }
        // returns best node index
        return index;
    }
    
    //Returns Nodes ID
    public Node getNode(String id) {
        for (Node node: availableNodes) {
            if (node.getName().equals(id)) {
                return node;
            }
        }
        return null;
    }
}
