package loadbalancer;

/**
 *
 * @author Maks
 */
public class Job {

    private final int jobID;
    private final int jobTime;

    public Job(int jobID, int jobTime) {
        this.jobID = jobID;
        this.jobTime = jobTime;
    }

    @Override
    public String toString() {
        return "[ " + jobID + ", " + jobTime + " ]";
    }
}
