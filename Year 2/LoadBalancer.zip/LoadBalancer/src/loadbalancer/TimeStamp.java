package loadbalancer;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author maks
 */
public class TimeStamp {
    public String timeStamp() {
        // Creates current date 
            Date currentDate = new Date();
            SimpleDateFormat timeStamp = new SimpleDateFormat("HH:mm:ss z dd.MM.yyyy");
            return timeStamp.format(currentDate);
    }
}
