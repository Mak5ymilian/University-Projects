package loadbalancer;

import java.net.InetAddress;
import java.util.LinkedList;

/**
 *
 * @author Maks
 */
public class Node {

    //data
    private String name;
    private final InetAddress ip;
    private final int port;
    private final int maxJobs;

    private final LinkedList<Job> jobs = new LinkedList<>();
    public int jobCount = 0;

    public Node(InetAddress ip, int port,  String name, int maxJobs) {
        this.name = name;
        this.ip = ip;
        this.port = port;
        this.maxJobs = maxJobs;
    }

    // getters & setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public InetAddress getIp() {
        return ip;
    }

    public int getPort() {
        return port;
    }

    public int getMaxJobs() {
        return maxJobs;
    }

    public LinkedList<Job> getJobs() {
        return jobs;
    }

    // normal methods
    public void addJob(Job job) {
        jobs.add(job);
        jobCount++;
    }

    public String getJob() {
        return jobs.get(jobs.size() - 1).toString();
    }

    public String getInfo() {
        return this.name + " " + this.ip + " " + this.port + " " + maxJobs;
    }
}

