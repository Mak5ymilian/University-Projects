/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loadbalancer;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;

/**
 *
 * @author Home
 */
public class StartSystem {

    private final int port;
    private int jobID = 0;
    private int currentNode = 0;
    private int nodeIDCounter = 0;
    private final Logger logger;
    private NodeManager manager;

    public StartSystem(int port) {
        this.port = port;
        this.logger = new Logger();
    }

    private DatagramSocket socket;

    public void runBalancer() throws IOException, InterruptedException {
        //Creates timestamp
        TimeStamp timestamp = new TimeStamp();
        //Linked list created for joblist
        LinkedList<Job> tempList = new LinkedList<>();
        LinkedList<Job> jobList = new LinkedList<>();
        manager = new NodeManager(this);
        socket = new DatagramSocket(port);
        socket.setSoTimeout(0);

        logger.out("---------------");
        logger.out("Started Load Balancer");
        logger.out("Listening on Port number: " + port);
        logger.out("---------------");

        boolean run = true;
        while (run) {

            byte[] packetData = new byte[1024];
            DatagramPacket packet = new DatagramPacket(packetData, packetData.length);
            socket.receive(packet);
            String message = new String(packetData, 0, packet.getLength());
            String[] elements = message.trim().split(",");
            switch (elements[0]) {
                //Receiving a REG message
                case "REG":
                    //Shows that the reg message is received
                    logger.out("---> Received a REG message from Node at: " + timestamp.timeStamp());
                    //Creates variables from message elements
                    InetAddress nodeMachineName = packet.getAddress();
                    int nodePort = packet.getPort();
                    int capacity = Integer.parseInt(elements[2]);
                    nodeIDCounter++;
                    String nodeID = "Node" + nodeIDCounter;
                    //Variable created to send ACK message
                    String ack = "Aknowledged by LoadBalancer," + nodeID;
                    // creates ACK packet
                    DatagramPacket ackpacket = new DatagramPacket(ack.getBytes(),ack.getBytes().length, nodeMachineName, nodePort);
                    //Sends ACK packet containing message to the port
                    socket.send(ackpacket);
                    //Node registered in node manager
                    manager.registerNode(nodeMachineName, nodePort, nodeID, capacity);
                    //shows registered node information
                    manager.showRegNode();
                    break;
                // Receiving Jobs from client
                case "JOB":
                    //Shows that the JOB message is received
                    logger.out("---> Received a JOB message from client at: " + timestamp.timeStamp());
                    //variable created to store element from message
                    int jobTime = Integer.parseInt(elements[1]);
                    //Variable increments by +1
                    jobID++;
                    //Job added to joblist with its ID and time to be completed
                    Job currentJob = new Job(jobID, jobTime);
                    jobList.add(currentJob);
                    //Confirmation to notify that job is added to the joblist
                    logger.out("JobID:" + jobID + " added to the Job list "
                            + "and to be completed in " + jobTime + " seconds!");
                    break;
                // Receiving Finish message from node
                case "FINISH":
                    logger.out("---> FINISH message received."
                            + " JobID: " + elements[1] + " Node ID: " +  elements[2] 
                            + " Finished at: " + timestamp.timeStamp());
                    manager.getNode(elements[2]).jobCount--;
                    break;
                case "STOP":
                    logger.out("---> SHUTDOWN message! at: " + timestamp.timeStamp());
                    broadcast("STOP");
                    System.exit(0);
                default:
                    logger.out("---> Got a message that i don't understand at: " 
                        + timestamp.timeStamp() + elements[0]);
            }
            // If there is a job in the Joblist (Joblist not empty)
            if (!jobList.isEmpty()) {
                // If there are available Nodes
                if (!manager.getAvailableNodes().isEmpty()) {
                    //Clears templist before looping through joblist 
                    tempList.clear();
                    for (Job job : jobList) {
                        // If the current node selected is out of bounds, i.e not in the list.
                        // Set the current node to the first node.
                        if (this.currentNode >= manager.getAvailableNodes().size()) {
                            this.currentNode = 0;
                        }
                        // Select specified node from nodemanager & add the job to it.
                        Node node = manager.getAvailableNodes().get(manager.getBestNodeIndex());
                        node.addJob(job);
                        // creates JOB packet
                        String jobString = node.getJob();
                        DatagramPacket jobpacket = new DatagramPacket(jobString.getBytes(),
                        jobString.length(), node.getIp(), node.getPort());
                        //Sends ACK packet containing message to the port
                        socket.send(jobpacket);
                        // Remove job from joblist, then set the current node to the next node.
                        //jobList.remove(job);
                        this.currentNode += 1;
                        //Adds job to templist to be removed later
                        tempList.add(job);
                    }
                    //removes job from joblist if in templist
                    //removes concurrentmodificationerror
                    for (Job job: tempList) {
                        jobList.remove(job);
                    }
                }
            }
        }
    }
    public void log(String message) {
        logger.out(message);
    }
    
    //Broadcasts message to all nodes
    public void broadcast(String message) throws IOException {
        for (Node node: manager.getAvailableNodes()) {
            socket.send(new DatagramPacket(message.getBytes(), message.getBytes().length, node.getIp(), node.getPort()));
        }
    }
}
