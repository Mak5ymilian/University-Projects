package sender;
/**
 *
 * @author Maks
 */
public class Client {
    private static String seconds;
    private static int amount;
    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    //Input in Args:
    //args[0] LoadBalancerMachine name
    //args[1] LoadBalancer port
    //args[2] Port to send packet
    //args[3] Message - JOB/STOP(Closes Balancer and all Nodes)
    //args[4] (Only for JOB) Seconds to complete job
    //args[5] (Only for JOB) Amount of jobs to send. 
    public static void main(String[] args) throws InterruptedException {
        try{
             //Assigns default variables if not all args used.
        if (args.length < 5 ){
            seconds = "0";
            amount = 1;
        } else {
            seconds = args[4];
            amount = Integer.parseInt(args[5]);
        }
        //Sends x amount of packets to the LoadBalancer
        for (int i = 0; i < amount; i++) {
            MessageSender job = new MessageSender();
            job.sendMessage(args[0],args[1],args[2],args[3],seconds);
        }
        } catch(ArrayIndexOutOfBoundsException error) {
            error.printStackTrace();
            Thread.sleep(500);
            System.out.println("""
                               Input in Args:
                                   args[0] LoadBalancerMachine name
                                   args[1] LoadBalancer port
                                   args[2] Port to send packet
                                   args[3] Message - JOB/STOP(Closes Balancer and all Nodes)
                                   args[4] (Only for JOB) Seconds to complete job
                                   args[5] (Only for JOB) Amount of jobs to send.""");
        }
       
    }
    
}
