package sender;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author Maks
 */
public class MessageSender {
    
    public void sendMessage(String inet, String port, String portt, String message, String seconds) {

        try {
            InetAddress address = InetAddress.getByName(inet);
            String job = message + "," + seconds;

            DatagramPacket packet = new DatagramPacket(job.getBytes(), job.getBytes().length, address, Integer.parseInt(port));

            try (DatagramSocket socket = new DatagramSocket(Integer.parseInt(portt))) {
                socket.send(packet);
            }

        } catch (IOException | NumberFormatException error) {
            error.printStackTrace();
        }
    }
}
